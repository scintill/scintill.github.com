/*
 * Crypto-JS v2.5.1
 * http://code.google.com/p/crypto-js/
 * (c) 2009-2011 by Jeff Mott. All rights reserved.
 * http://code.google.com/p/crypto-js/wiki/License
 */
(function(){var b=Crypto,j=b.util,e=b.charenc,i=e.UTF8,k=e.Binary;b.HMAC=function(c,f,a,d){f.constructor==String&&(f=i.stringToBytes(f));a.constructor==String&&(a=i.stringToBytes(a));a.length>c._blocksize*4&&(a=c(a,{asBytes:!0}));for(var b=a.slice(0),a=a.slice(0),g=0;g<c._blocksize*4;g++)b[g]^=92,a[g]^=54;var h=d?d.callback:void 0,e=function(a){a=d&&d.asBytes?a:d&&d.asString?k.bytesToString(a):j.bytesToHex(a);if(h)h(a);else return a};if(h)c(a.concat(f),{asBytes:!0,callback:function(a){c(b.concat(a),
{asBytes:!0,callback:e})}});else return e(c(b.concat(c(a.concat(f),{asBytes:!0})),{asBytes:!0}))}})();
